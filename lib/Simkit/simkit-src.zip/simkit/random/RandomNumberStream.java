package simkit.random;

/**
 * @since 1096
 * @version $Id: RandomNumberStream.java 1096 2008-07-01 18:24:19Z kastork $
 * @author Kirk Stork (The MOVES Institute)
 */
public interface RandomNumberStream extends RandomNumber {
    public void setStreamAndSubstream(int stream, int substream);
    public int getStreamID();
    public int getSubstreamID();
}
